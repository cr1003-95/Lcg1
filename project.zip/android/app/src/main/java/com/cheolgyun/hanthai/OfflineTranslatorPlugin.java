package com.cheolgyun.hanthai;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

@CapacitorPlugin(name = "OfflineTranslator")
public class OfflineTranslatorPlugin extends Plugin {
    private Translator createTranslator(String direction) {
        boolean koToTh = !"th-ko".equals(direction);
        TranslatorOptions options = new TranslatorOptions.Builder()
            .setSourceLanguage(koToTh ? TranslateLanguage.KOREAN : TranslateLanguage.THAI)
            .setTargetLanguage(koToTh ? TranslateLanguage.THAI : TranslateLanguage.KOREAN)
            .build();
        return Translation.getClient(options);
    }

    @PluginMethod
    public void prepareBoth(PluginCall call) {
        Translator koTh = createTranslator("ko-th");
        Translator thKo = createTranslator("th-ko");
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        Tasks.whenAll(
            koTh.downloadModelIfNeeded(conditions),
            thKo.downloadModelIfNeeded(conditions)
        ).addOnSuccessListener(unused -> {
            koTh.close();
            thKo.close();
            JSObject result = new JSObject();
            result.put("ready", true);
            call.resolve(result);
        }).addOnFailureListener(error -> {
            koTh.close();
            thKo.close();
            call.reject("번역 자료를 내려받지 못했습니다.", error);
        });
    }

    @PluginMethod
    public void translate(PluginCall call) {
        String text = call.getString("text", "").trim();
        String direction = call.getString("direction", "ko-th");
        if (text.isEmpty()) {
            call.reject("번역할 문장이 없습니다.");
            return;
        }
        Translator translator = createTranslator(direction);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
            .onSuccessTask(unused -> translator.translate(text))
            .addOnSuccessListener(translated -> {
                translator.close();
                JSObject result = new JSObject();
                result.put("translation", translated);
                call.resolve(result);
            })
            .addOnFailureListener(error -> {
                translator.close();
                call.reject("오프라인 번역 자료가 준비되지 않았습니다.", error);
            });
    }
}
