package com.cheolgyun.hanthai;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.icu.text.Transliterator;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;
import java.util.Locale;

@CapacitorPlugin(name = "NativeSpeech")
public class NativeSpeechPlugin extends Plugin {
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;

    @Override
    public void load() {
        initializeTts();
    }

    private void initializeTts() {
        String preferredEngine = null;
        try {
            getContext().getPackageManager().getApplicationInfo("com.google.android.tts", 0);
            preferredEngine = "com.google.android.tts";
        } catch (PackageManager.NameNotFoundException ignored) {
            // Use the phone's default voice engine when Google Speech Services is absent.
        }
        TextToSpeech.OnInitListener listener = status -> ttsReady = status == TextToSpeech.SUCCESS;
        textToSpeech = preferredEngine == null
            ? new TextToSpeech(getContext(), listener)
            : new TextToSpeech(getContext(), listener, preferredEngine);
    }

    @PluginMethod
    public void recognize(PluginCall call) {
        String language = call.getString("language", "ko-KR");
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false);
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
            language.startsWith("th") ? "พูดภาษาไทย" : "한국어로 말씀해 주세요");
        try {
            startActivityForResult(call, intent, "speechResult");
        } catch (ActivityNotFoundException error) {
            call.reject("휴대폰에 음성 인식 기능이 설치되어 있지 않습니다.", error);
        }
    }

    @ActivityCallback
    private void speechResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent data = result.getData();
        if (result.getResultCode() == Activity.RESULT_OK && data != null) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (matches != null && !matches.isEmpty()) {
                JSObject response = new JSObject();
                response.put("text", matches.get(0));
                call.resolve(response);
                return;
            }
        }
        JSObject response = new JSObject();
        response.put("text", "");
        response.put("cancelled", true);
        call.resolve(response);
    }

    @PluginMethod
    public void speak(PluginCall call) {
        String text = call.getString("text", "").trim();
        String language = call.getString("language", "th-TH");
        if (text.isEmpty()) {
            call.reject("읽을 문장이 없습니다.");
            return;
        }
        if (textToSpeech == null || !ttsReady) {
            call.reject("음성 엔진을 준비하는 중입니다. 잠시 후 다시 눌러주세요.");
            return;
        }
        Locale locale = language.startsWith("th")
            ? new Locale("th", "TH")
            : Locale.KOREA;
        int available = textToSpeech.setLanguage(locale);
        if (available == TextToSpeech.LANG_MISSING_DATA || available == TextToSpeech.LANG_NOT_SUPPORTED) {
            call.reject("선택한 언어의 음성이 휴대폰에 설치되어 있지 않습니다.");
            return;
        }
        textToSpeech.setSpeechRate(language.startsWith("th") ? 0.76f : 0.9f);
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hanthai-utterance");
        call.resolve();
    }

    @PluginMethod
    public void openVoiceSettings(PluginCall call) {
        try {
            Intent install = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
            getActivity().startActivity(install);
        } catch (ActivityNotFoundException error) {
            Intent settings = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            getActivity().startActivity(settings);
        }
        call.resolve();
    }

    @PluginMethod
    public void romanize(PluginCall call) {
        String text = call.getString("text", "").trim();
        JSObject result = new JSObject();
        if (text.isEmpty()) {
            result.put("romanized", "");
            call.resolve(result);
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                Transliterator transliterator = Transliterator.getInstance("Thai-Latin");
                result.put("romanized", transliterator.transliterate(text));
                call.resolve(result);
                return;
            } catch (IllegalArgumentException ignored) {
                // Fall through to the listening hint if the device ICU data lacks Thai-Latin.
            }
        }
        result.put("romanized", "발음 듣기 버튼으로 정확한 태국어 음성을 확인하세요.");
        call.resolve(result);
    }

    @Override
    protected void handleOnDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
    }
}
